@pushonce('scripts')
    <script type="importmap">
        {
            "imports": {
                "ckeditor5": "https://cdn.ckeditor.com/ckeditor5/43.2.0/ckeditor5.js",
                "ckeditor5/": "https://cdn.ckeditor.com/ckeditor5/43.2.0/"
            }
        }
    </script>
@endpushonce
<link rel="stylesheet" href="https://cdn.ckeditor.com/ckeditor5/43.2.0/ckeditor5.css" />
<x-dynamic-component
    :component="$getFieldWrapperView()"
    :id="$getId()"
    :label="$getLabel()"
    :label-sr-only="$isLabelHidden()"
    :helper-text="$getHelperText()"
    :hint="$getHint()"
    :hint-icon="$getHintIcon()"
    :required="$isRequired()"
    :state-path="$getStatePath()"
    :field="$field"
>
    <div
        wire:ignore
        x-data="{ state: $wire.entangle('{{ $getStatePath() }}'), isUpdatingFromEditor: false}"
        x-init="
            import('ckeditor5').then(module => {
                const { 	ClassicEditor,
                AccessibilityHelp,
                Alignment,
                Autoformat,
                AutoImage,
                AutoLink,
                Autosave,
                BalloonToolbar,
                Base64UploadAdapter,
                BlockQuote,
                Bold,
                Code,
                CodeBlock,
                Essentials,
                FindAndReplace,
                FontBackgroundColor,
                FontColor,
                FontFamily,
                FontSize,
                FullPage,
                GeneralHtmlSupport,
                Heading,
                Highlight,
                HorizontalLine,
                HtmlComment,
                HtmlEmbed,
                ImageBlock,
                ImageCaption,
                ImageInline,
                ImageInsert,
                ImageInsertViaUrl,
                ImageResize,
                ImageStyle,
                ImageTextAlternative,
                ImageToolbar,
                ImageUpload,
                Indent,
                IndentBlock,
                Italic,
                Link,
                LinkImage,
                List,
                ListProperties,
                Markdown,
                MediaEmbed,
                PageBreak,
                Paragraph,
                PasteFromMarkdownExperimental,
                PasteFromOffice,
                RemoveFormat,
                SelectAll,
                ShowBlocks,
                SourceEditing,
                SpecialCharacters,
                SpecialCharactersArrows,
                SpecialCharactersCurrency,
                SpecialCharactersEssentials,
                SpecialCharactersLatin,
                SpecialCharactersMathematical,
                SpecialCharactersText,
                Strikethrough,
                Style,
                Subscript,
                Superscript,
                Table,
                TableCaption,
                TableCellProperties,
                TableColumnResize,
                TableProperties,
                TableToolbar,
                TextPartLanguage,
                TextTransformation,
                Title,
                TodoList,
                Underline,
                Undo } = module;
                ClassicEditor
                    .create($refs.ckEditor, {
                        plugins: [
                                    AccessibilityHelp,
                                    Alignment,
                                    Autoformat,
                                    AutoImage,
                                    AutoLink,
                                    Autosave,
                                    BalloonToolbar,
                                    Base64UploadAdapter,
                                    BlockQuote,
                                    Bold,
                                    Code,
                                    CodeBlock,
                                    Essentials,
                                    FindAndReplace,
                                    FontBackgroundColor,
                                    FontColor,
                                    FontFamily,
                                    FontSize,
                                    FullPage,
                                    GeneralHtmlSupport,
                                    Heading,
                                    Highlight,
                                    HorizontalLine,
                                    HtmlComment,
                                    HtmlEmbed,
                                    ImageBlock,
                                    ImageCaption,
                                    ImageInline,
                                    ImageInsert,
                                    ImageInsertViaUrl,
                                    ImageResize,
                                    ImageStyle,
                                    ImageTextAlternative,
                                    ImageToolbar,
                                    ImageUpload,
                                    Indent,
                                    IndentBlock,
                                    Italic,
                                    Link,
                                    LinkImage,
                                    List,
                                    ListProperties,
                                    Markdown,
                                    MediaEmbed,
                                    PageBreak,
                                    Paragraph,
                                    PasteFromMarkdownExperimental,
                                    PasteFromOffice,
                                    RemoveFormat,
                                    SelectAll,
                                    ShowBlocks,
                                    SourceEditing,
                                    SpecialCharacters,
                                    SpecialCharactersArrows,
                                    SpecialCharactersCurrency,
                                    SpecialCharactersEssentials,
                                    SpecialCharactersLatin,
                                    SpecialCharactersMathematical,
                                    SpecialCharactersText,
                                    Strikethrough,
                                    Style,
                                    Subscript,
                                    Superscript,
                                    Table,
                                    TableCaption,
                                    TableCellProperties,
                                    TableColumnResize,
                                    TableProperties,
                                    TableToolbar,
                                    TextPartLanguage,
                                    TextTransformation,

                                    TodoList,
                                    Underline,
                                    Undo],
                        toolbar: [
                            'undo',
                            'redo',
                            '|',
                            'sourceEditing',
                            'showBlocks',
                            '|',
                            'heading',
                            'style',
                            '|',
                            'fontSize',
                            'fontFamily',
                            'fontColor',
                            'fontBackgroundColor',
                            '|',
                            'bold',
                            'italic',
                            'underline',
                            '|',
                            'link',
                            'insertImage',
                            'insertTable',
                            'highlight',
                            'blockQuote',
                            'codeBlock',
                            '|',
                            'alignment',
                            '|',
                            'bulletedList',
                            'numberedList',
                            'todoList',
                            'outdent',
                            'indent'
                        ],
                       balloonToolbar: ['bold', 'italic', '|', 'link', 'insertImage', '|', 'bulletedList', 'numberedList'],
                       fontFamily: {
		supportAllValues: true
	},
	fontSize: {
		options: [10, 12, 14, 'default', 18, 20, 22],
		supportAllValues: true
	},heading: {
		options: [
			{
				model: 'paragraph',
				title: 'Paragraph',
				class: 'ck-heading_paragraph'
			},
			{
				model: 'heading1',
				view: 'h1',
				title: 'Heading 1',
				class: 'ck-heading_heading1'
			},
			{
				model: 'heading2',
				view: 'h2',
				title: 'Heading 2',
				class: 'ck-heading_heading2'
			},
			{
				model: 'heading3',
				view: 'h3',
				title: 'Heading 3',
				class: 'ck-heading_heading3'
			},
			{
				model: 'heading4',
				view: 'h4',
				title: 'Heading 4',
				class: 'ck-heading_heading4'
			},
			{
				model: 'heading5',
				view: 'h5',
				title: 'Heading 5',
				class: 'ck-heading_heading5'
			},
			{
				model: 'heading6',
				view: 'h6',
				title: 'Heading 6',
				class: 'ck-heading_heading6'
			}
		]
	},htmlSupport: {
		allow: [
			{
				name: /^.*$/,
				styles: true,
				attributes: true,
				classes: true
			}
		]
	},
	image: {
		toolbar: [
			'toggleImageCaption',
			'imageTextAlternative',
			'|',
			'imageStyle:inline',
			'imageStyle:wrapText',
			'imageStyle:breakText',
			'|',
			'resizeImage'
		]
	},link: {
		addTargetToExternalLinks: true,
		defaultProtocol: 'https://',
		decorators: {
			toggleDownloadable: {
				mode: 'manual',
				label: 'Downloadable',
				attributes: {
					download: 'file'
				}
			}
		}
	},list: {
		properties: {
			styles: true,
			startIndex: true,
			reversed: true
		}
	},
	menuBar: {
		isVisible: true
	},style: {
		definitions: [
			{
				name: 'Article category',
				element: 'h3',
				classes: ['category']
			},
			{
				name: 'Title',
				element: 'h2',
				classes: ['document-title']
			},
			{
				name: 'Subtitle',
				element: 'h3',
				classes: ['document-subtitle']
			},
			{
				name: 'Info box',
				element: 'p',
				classes: ['info-box']
			},
			{
				name: 'Side quote',
				element: 'blockquote',
				classes: ['side-quote']
			},
			{
				name: 'Marker',
				element: 'span',
				classes: ['marker']
			},
			{
				name: 'Spoiler',
				element: 'span',
				classes: ['spoiler']
			},
			{
				name: 'Code (dark)',
				element: 'pre',
				classes: ['fancy-code', 'fancy-code-dark']
			},
			{
				name: 'Code (bright)',
				element: 'pre',
				classes: ['fancy-code', 'fancy-code-bright']
			}
		]
	},
	table: {
		contentToolbar: ['tableColumn', 'tableRow', 'mergeTableCells', 'tableProperties', 'tableCellProperties']
	}
                    })
                    .then(newEditor => {
                        editor = newEditor;

                        editor.model.document.on('change:data', () => {
                            isUpdatingFromEditor = true;
                            state = editor.getData();
                            isUpdatingFromEditor = false;
                        });
                        function putCursorToEnd() {
                            editor.selection.select(editor.getBody(), true);
                            editor.selection.collapse(false);
                        }
                         $watch('state', function(newstate) {
                            // unfortunately livewire doesn't provide a way to 'unwatch' so this listener sticks
                            // around even after this component is torn down. Which means that we need to check
                            // that editor.container exists. If it doesn't exist we do nothing because that means
                            // the editor was removed from the DOM
                            if (editor.container && newstate !== editor.getContent()) {
                                editor.resetContent(newstate || '');
                                putCursorToEnd();
                            }
                        });
                    })
                    .catch(error => {
                        console.error(error);
                    });
            });
        "
    >
        <div class="block w-full max-w-none rounded-lg border border-gray-300 bg-white p-3 opacity-70 shadow-sm transition duration-75 prose dark:prose-invert dark:border-gray-600 dark:bg-gray-700 dark:text-white overflow-y-auto
        editor-container editor-container_classic-editor editor-container_include-style" id="editor-container">
            <div class="editor-container__editor">
                <textarea x-ref="ckEditor"
                          id="{{ $getId() }}"
                          name="{{ $getId() }}"
                          x-model="state"
                  {{ $attributes->merge(['class' => 'form-control']) }}>
        </textarea>
            </div>
        </div>

    </div>
</x-dynamic-component>
