<?php

namespace App\Tables\Columns;

use Filament\Tables\Columns\Column;

class UserPhotoName extends Column
{
    protected string $view = 'tables.columns.user-photo-name';
}
