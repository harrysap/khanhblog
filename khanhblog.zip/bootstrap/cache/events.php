<?php return array (
  'App\\Providers\\EventServiceProvider' => 
  array (
    'App\\Events\\BlogPublished' => 
    array (
      0 => 'App\\Listeners\\SendBlogPublishedNotification',
    ),
  ),
  'Illuminate\\Foundation\\Support\\Providers\\EventServiceProvider' => 
  array (
  ),
);