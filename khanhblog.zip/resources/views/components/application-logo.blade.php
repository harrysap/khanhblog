<a href="/">
    <img {{ $attributes->merge(['class' => 'h-full']) }} src="{{ asset('assets/images/grant-thornton-white-logo.png') }}" alt="grant-thornton-tsc-erp" id="grant-thorton-logo">
</a>
