<x-filament-widgets::widget>
    <x-filament::section class="flex flex-col items-center justify-center">
    </x-filament::section>
</x-filament-widgets::widget>
