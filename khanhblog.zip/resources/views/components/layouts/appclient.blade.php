@props([
    'heading' => null,
])

<x-layouts.base {{ $attributes }}>
    {{ $slot }}
</x-layouts.base>
